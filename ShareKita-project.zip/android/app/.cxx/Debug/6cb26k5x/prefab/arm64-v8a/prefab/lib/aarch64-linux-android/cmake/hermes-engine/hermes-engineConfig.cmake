if(NOT TARGET hermes-engine::hermesvm)
add_library(hermes-engine::hermesvm SHARED IMPORTED)
set_target_properties(hermes-engine::hermesvm PROPERTIES
    IMPORTED_LOCATION "C:/Users/JANCEL/.gradle/caches/9.4.1/transforms/0cbab063a36c26b564561339905d9b51/transformed/hermes-android-260318099.0.4-debug/prefab/modules/hermesvm/libs/android.arm64-v8a/libhermesvm.so"
    INTERFACE_INCLUDE_DIRECTORIES "C:/Users/JANCEL/.gradle/caches/9.4.1/transforms/0cbab063a36c26b564561339905d9b51/transformed/hermes-android-260318099.0.4-debug/prefab/modules/hermesvm/include"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

