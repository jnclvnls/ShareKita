import { requireNativeModule } from 'expo-modules-core';

type HotspotModule = {
  connect(ssid: string, password: string, wpa3: boolean, hidden: boolean): Promise<string>;
  disconnect(): Promise<void>;
  openHotspotSettings(): Promise<void>;
  openWifiSettings(): Promise<void>;
  generateSessionKey(): Promise<string>;
  generatePairingToken(): Promise<string>;
  encryptChunk(key: string, transferId: string, index: number, data: string): Promise<string>;
  decryptChunk(key: string, transferId: string, index: number, data: string): Promise<string>;
};

const mod = () => requireNativeModule<HotspotModule>('ShareKitaHotspot');

/** Resolves with the receiver's gateway IP ('' if Android did not report one). */
export function connectToHotspot(ssid = '', password = '', wpa3 = false, hidden = false) {
  return mod().connect(ssid, password, wpa3, hidden);
}

export function disconnectFromHotspot() {
  return mod().disconnect();
}

export function openHotspotSettings() {
  return mod().openHotspotSettings();
}

export function openWifiSettings() {
  return mod().openWifiSettings();
}

export function generateSessionKey() {
  return mod().generateSessionKey();
}

export function generatePairingToken() {
  return mod().generatePairingToken();
}

export function encryptChunk(key: string, transferId: string, index: number, data: string) {
  return mod().encryptChunk(key, transferId, index, data);
}

export function decryptChunk(key: string, transferId: string, index: number, data: string) {
  return mod().decryptChunk(key, transferId, index, data);
}

